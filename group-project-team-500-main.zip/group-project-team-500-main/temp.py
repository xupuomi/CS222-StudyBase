import http.client
import xml.etree.ElementTree as ET

# Base URL for each subject
base_url = "courses.illinois.edu"

# Function to get the list of courses for each subject
def get_courses(subject_id, subject_name, subject_url):
    print(f"Retrieving courses for subject: {subject_name} ({subject_id})")

    # Create a connection to the server
    conn = http.client.HTTPSConnection(base_url)

    # Request the XML data for the subject
    conn.request("GET", subject_url)
    response = conn.getresponse()

    # Check if the request was successful
    if response.status != 200:
        print(f"Failed to retrieve data for {subject_name}: {response.status} {response.reason}")
        conn.close()
        return

    # Read the XML response content
    xml_content = response.read()

    # Parse the XML data
    subject_tree = ET.fromstring(xml_content)
    courses = subject_tree.findall(".//course")

    # Extract course information
    course_list = []
    for course in courses:
        course_id = course.get("id")
        course_name = course.findtext("label")
        course_list.append((course_id, course_name))

    # Display the list of courses
    for course_id, course_name in course_list:
        print(f"  Course ID: {course_id}, Course Name: {course_name}")

    # Close the connection
    conn.close()

# Parse the main XML response
def main():
    # Define the path for the XML data
    term_path = "/cisapp/explorer/schedule/2024/spring.xml"

    # Create a connection to the server
    conn = http.client.HTTPSConnection(base_url)

    # Request the main XML data
    conn.request("GET", term_path)
    response = conn.getresponse()

    # Check if the request was successful
    if response.status != 200:
        print(f"Failed to retrieve data: {response.status} {response.reason}")
        conn.close()
        return

    # Read the XML response content
    xml_content = response.read()

    # Parse the XML response
    root = ET.fromstring(xml_content)
    subjects = root.findall(".//subject")

    # Iterate through each subject and get the courses
    for subject in subjects:
        subject_id = subject.get("id")
        subject_name = subject.text
        subject_url = subject.get("href")
        get_courses(subject_id, subject_name, subject_url)

    # Close the connection
    conn.close()

if __name__ == "__main__":
    main()