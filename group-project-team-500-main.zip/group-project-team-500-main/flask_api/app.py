from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Users(db.Model):
    username = db.Column(db.String(256), primary_key =  True)
    password = db.Column(db.String(256), nullable = False)
    firstname = db.Column(db.String(256), nullable = False)
    lastname = db.Column(db.String(256), nullable = False)
    email = db.Column(db.String(256), nullable = False, unique = True)

    def __repr__(self):
        return '<Username %r>' % self.username

# JSON 
# "username": naomil4
# "password": 12345
# "firstname": Naomi
# "lastname": Lin
# "email": naomil4@illinois.edu
"""
JSON request body from frontend
await axios.post('/register', {username: '', password: '', firstname: '', lastname: '', email: ''})

"""

@app.route('/register', methods = ['POST'])
def register():
    # body is a variable that takes in json input from post, and then we parse it to set each of the user properties
    body = request.json
    username = body["username"]
    password = body["password"]
    firstname = body["firstname"]
    lastname = body["lastname"]
    email = body["email"]

    # creating a new user and adding it to the db
    newUser = Users(username=username, password=password, firstname=firstname, lastname=lastname, email=email)
    db.session.add(newUser)
    db.session.commit()
    
    # get info from table corresponding to the username (unique) and print back
    ret = Users.query.get(username)
    return jsonify({"username": ret.username, "password": ret.password, "firstname": ret.firstname, "lastname": ret.lastname, "email": ret.email})

# import os
# from io import BytesIO
# from flask import Flask, request, render_template, jsonify, send_file
# from werkzeug.utils import secure_filename
# # import sqlalchemy as db
# # from sqlalchemy import create_engine, MetaData, Table, Column, Numeric, Integer, VARCHAR, update
# from flask_sqlalchemy import SQLAlchemy

# app = Flask(__name__)
# app.config['SQLAlCHEMY_DATABASE_URI'] = 'sqlite://db.sqlite3'
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# db = SQLAlchemy(app)

# class Upload(db.Model):
#     file_id = db.Column(db.Integer, primary_key =  True)
#     filename = db.Column(db.String(50))
#     data = db.Column(db.LargeBinary)
#     user_id = db.Column(db.String(50), db.ForeignKey('users.username'))
#     course = db.Column(db.String(50), db.ForeignKey('courses.course_number'))

    
# class Users(db.Model):
#     username = db.Column(db.String(50), primary_key =  True)
#     password = db.Column(db.String(50))
#     email = db.Column(db.String(50))
#     upload = db.relationship('Upload', backref = 'users')

# #how to do with multiple primary keys
# class Favorites(db.Model):
#     username = db.Column(db.String(50), primary_key =  True)
#     course_number = db.Column(db.String(50), primary_key =  True)
    

# class Courses(db.Model):
#     course_number = db.Column(db.String(50), primary_key =  True)
#     professor = db.Column(db.String(50))
#     subject = db.Column(db.String(50))
#     upload = db.relationship('Upload', backref = 'courses')

# # Dummy database file
# # DATABASE_FILE = "database.txt"
# # DATABASE_NOTE_ID = "1234"

# # Ensure the dummy database file exists
# # f not os.path.exists(DATABASE_FILE):
# #     open(DATABASE_FILE, 'w').close()

# # @app.route('/upload-note', methods=['POST'])
# # def upload_note():

# #     if request.method == 'POST':
# #         if 'file' not in request.files:
# #             print('No file part')
# #             return redirect(request.url)
# #         file = request.files['file']

# #         # Check if no files were selected
# #         if len(files) == 0:
# #             return 'No selected files'

# #         # Process each file
# #         for file in files:
# #             # Check if the file has a filename
# #             if file.filename == '':
# #                 return 'No selected file'

# #             # Process the file content and store it in the database file
# #             file_content = file.read().decode("utf-8")
# #             with open(DATABASE_FILE, "a") as f:
# #                 f.write(file_content + "\n")
# #                 # Generate note_id or perform any other necessary operations

# #         return 'Files uploaded successfully'

# #     elif request.method == 'GET':
# #         # Handle GET request (if needed)
# #         # You can return a form or any other response for GET requests
# #         return 'This is the upload-note endpoint. Please use POST method to upload files.'

# #     else:
# #         return 'Method not allowed'

# app.config["UPLOAD_FOLDER"] = "static/"

# @app.route('/', methods =  ['GET', 'POST'])
# def upload_file():
#     if request.method == 'POST':
#         file = request.files['file']
#         upload = Upload(filename = file.filename, data = file.read())
#         db.session.add(upload)
#         db.session.commit()
#         return f'Uploaded: {file.filename}'
#     return render_template('index.html')

# @app.route('/display', methods = ['GET', 'POST'])
# def display_file():
#     if request.method == 'POST':
#         f = request.files['file']
#         filename = secure_filename(f.filename)

#         f.save(app.config['UPLOAD_FOLDER'] + filename)

#         file = open(app.config['UPLOAD_FOLDER'] + filename,"r")
#         content = file.read()   
        
#     return render_template('content.html', content=content) 

# @app.route('/download/<upload_id>')
# def download(upload_id):
#     upload = Upload.query.filter_by(id=upload_id).first()
#     return send_file(BytesIO(upload.data), attachment_filename = upload.filename, as_attachment=True)

# # Route to edit note
# # @app.route('/edit-note/<int:note_id>', methods=['PUT'])
# # def edit_note(DATABASE_NOTE_ID):
# #     # Here you would implement logic to edit a note based on its ID
# #     data = request.get_json()
# #     try:
# #         with open(DATABASE_FILE, "r+") as f:
# #             lines = f.readlines()
# #             lines[DATABASE_NOTE_ID] = data + "\n"
# #             f.seek(0)
# #             f.writelines(lines)
# #         return jsonify({'message': 'Note edited successfully'})
# #     except: 
# #         return jsonify({'message': 'Unable to edit note'})

# # Route to delete note
# # @app.route('/delete-note/<int:note_id>', methods=['DELETE'])
# # def delete_note(DATABASE_NOTE_ID):
# #     # Here you would implement logic to delete a note based on its ID
# #     # For simplicity, let's just remove the note from the 'notes' list
# #     try:
# #         with open(DATABASE_FILE, "r+") as f:
# #             lines = f.readlines()
# #             del lines[DATABASE_NOTE_ID]
# #             f.seek(0)
# #             f.truncate()
# #             f.writelines(lines)
# #         return jsonify({'message': 'Note deleted successfully'})
# #     except:
# #         return jsonify({'message': 'Unable to delete note'})
    
# # Route to get all notes
# # @app.route('/notes', methods=['GET'])
# # def get_all_notes():
# #     with open(DATABASE_FILE, "r") as f:
# #         notes = f.readlines()
# #     return jsonify({'notes': notes})

# # Route to get all notes from a certain class: display certain amount in reverse chronological order

# @app.route('/get_uiuc_classes')
# def get_uiuc_classes():
#     # Specify the API endpoint URL
#     api_url = 'http://rest.cis.illinois.edu'

#     try:
#         # Make a GET request to the API
#         response = request.get(api_url)

#         # Check if the request was successful (status code 200)
#         if response.status_code == 200:
#             # Parse the JSON data from the response
#             classes_data = response.json()

#             # Return the data as JSON
#             return jsonify(classes_data)
#         else:
#             # If the request was not successful, return an error message
#             return jsonify({'error': 'Failed to retrieve UIUC classes'}), response.status_code
#     except request.exceptions.RequestException as e:
#         # Handle any exceptions that may occur during the request
#         return jsonify({'error': f'Request failed: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=8000)

